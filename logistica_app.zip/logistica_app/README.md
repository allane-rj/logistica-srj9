# 🚚 Logística SRJ9 — Envios Extra

App para cruzar dados do Looker Studio com os mapeamentos de rotas otimizadas,
filtrando automaticamente pela transportadora **Envios Extra**.

---

## 📁 Estrutura do projeto

```
logistica_app/
├── app.py              ← App principal (não editar)
├── requirements.txt    ← Dependências (não editar)
└── README.md           ← Este arquivo
```

---

## 🚀 Deploy no Streamlit Cloud (passo a passo)

### Pré-requisito: conta no GitHub (gratuita)
Acesse https://github.com e crie uma conta se ainda não tiver.

---

### Passo 1 — Criar repositório no GitHub

1. Acesse https://github.com/new
2. Nome do repositório: `logistica-srj9`
3. Deixe **Público** (necessário para o plano gratuito do Streamlit)
4. Clique em **Create repository**

---

### Passo 2 — Fazer upload dos arquivos

Na página do repositório recém-criado:

1. Clique em **"uploading an existing file"** (link no centro da tela)
2. Arraste os 3 arquivos: `app.py`, `requirements.txt`, `README.md`
3. Clique em **Commit changes**

---

### Passo 3 — Publicar no Streamlit Cloud

1. Acesse https://share.streamlit.io
2. Clique em **"Sign in with GitHub"** e autorize
3. Clique em **"New app"**
4. Preencha:
   - **Repository**: `seu-usuario/logistica-srj9`
   - **Branch**: `main`
   - **Main file path**: `app.py`
5. Clique em **Deploy!**

Pronto! Em ~2 minutos você terá um link público como:
`https://seu-usuario-logistica-srj9-app-xxxxx.streamlit.app`

---

## 📖 Como usar o app

### A — Carregar mapeamento de rotas
Na barra lateral, em **"CSVs de Mapeamento de Rotas"**, faça upload do(s) arquivo(s)
de mapeamento (ex: `Rotas_Transportadora_SD_28mar.csv`).

O arquivo deve ter as colunas:
- `Rota otimizada` (ex: K2_SD)
- `Rota original` (ex: SD_5)
- `Transportadora` (ex: Envios Extra)

### B — Exportar do Looker Studio
1. Abra o Looker Studio
2. Vá na tabela **"placas de hoje"**
3. Filtre por **SVC = SRJ9** e a **data atual**
4. Clique nos três pontinhos → **Download CSV**

### C — Processar
1. Carregue o CSV do Looker no campo **"CSV do Looker"**
2. Confirme o SVC e a data
3. Clique em **▶️ Processar**
4. Baixe o relatório em Excel ou CSV

---

## 📋 Colunas do relatório gerado

| Coluna | Descrição |
|---|---|
| Cluster / SVC | Centro de distribuição |
| Motorista | Nome do motorista (do Looker) |
| Placa | Placa do veículo (do Looker) |
| Rota Original (Looker) | Rota que o Looker atribuiu |
| Rota Otimizada (Planej.) | Rota conforme seu planejamento |
| Tipo de Veículo | Tipo do veículo |
| Status | ✅ Correto / ⚠️ Divergência / ❓ Não mapeada |

---

## ➕ Adicionar novas regiões

Sempre que tiver um novo CSV de rotas (outro cluster), basta fazer upload
junto com os demais no campo de mapeamento. O app consolida tudo automaticamente.

---

## 🛠️ Suporte

Em caso de dúvidas sobre colunas não detectadas, verifique o **Log de execução**
(no final da página após processar) — ele mostra exatamente o que foi encontrado.
